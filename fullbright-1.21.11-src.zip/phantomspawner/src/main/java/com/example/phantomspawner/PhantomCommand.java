package com.example.phantomspawner;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.BlockPosArgumentType;
import net.minecraft.command.argument.IdentifierArgumentType;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/**
 * /phantomspawner add <x y z> <mob>
 * /phantomspawner remove <x y z>
 * /phantomspawner list
 */
public class PhantomCommand {

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("phantomspawner")
                .requires(CommandManager.requirePermissionLevel(CommandManager.GAMEMASTERS_CHECK))
                .then(literal("add")
                        .then(argument("pos", BlockPosArgumentType.blockPos())
                                .then(argument("mob", IdentifierArgumentType.identifier())
                                        .suggests((c, b) -> CommandSource.suggestIdentifiers(
                                                Registries.ENTITY_TYPE.getIds(), b))
                                        .executes(PhantomCommand::add))))
                .then(literal("remove")
                        .then(argument("pos", BlockPosArgumentType.blockPos())
                                .executes(PhantomCommand::remove)))
                .then(literal("list").executes(PhantomCommand::list)));
    }

    private static String dim(CommandContext<ServerCommandSource> c) {
        return c.getSource().getWorld().getRegistryKey().getValue().toString();
    }

    private static int add(CommandContext<ServerCommandSource> c) {
        BlockPos pos = BlockPosArgumentType.getBlockPos(c, "pos");
        Identifier id = IdentifierArgumentType.getIdentifier(c, "mob");

        if (!Registries.ENTITY_TYPE.containsId(id)) {
            c.getSource().sendError(Text.literal("Неизвестный моб: " + id));
            return 0;
        }
        EntityType<?> type = Registries.ENTITY_TYPE.get(id);
        if (type.getSpawnGroup() == SpawnGroup.MISC) {
            c.getSource().sendError(Text.literal(id + " — это не моб, его нельзя заспавнить."));
            return 0;
        }

        String dim = dim(c);
        SpawnerStorage.SPAWNERS.removeIf(s -> s.at(dim, pos));
        SpawnerStorage.SPAWNERS.add(new SpawnerData(dim, pos, id.toString()));
        SpawnerStorage.save();

        c.getSource().sendFeedback(() -> Text.literal("Фантомный спавнер (" + id + ") создан на "
                + pos.getX() + " " + pos.getY() + " " + pos.getZ()), true);
        return 1;
    }

    private static int remove(CommandContext<ServerCommandSource> c) {
        BlockPos pos = BlockPosArgumentType.getBlockPos(c, "pos");
        String dim = dim(c);
        boolean removed = SpawnerStorage.SPAWNERS.removeIf(s -> s.at(dim, pos));
        if (!removed) {
            c.getSource().sendError(Text.literal("На этих координатах спавнера нет."));
            return 0;
        }
        SpawnerStorage.save();
        c.getSource().sendFeedback(() -> Text.literal("Спавнер удалён."), true);
        return 1;
    }

    private static int list(CommandContext<ServerCommandSource> c) {
        if (SpawnerStorage.SPAWNERS.isEmpty()) {
            c.getSource().sendFeedback(() -> Text.literal("Спавнеров нет."), false);
            return 0;
        }
        for (SpawnerData s : SpawnerStorage.SPAWNERS) {
            c.getSource().sendFeedback(() -> Text.literal(s.dimension + " | "
                    + s.x + " " + s.y + " " + s.z + " | " + s.mob), false);
        }
        return SpawnerStorage.SPAWNERS.size();
    }
}
