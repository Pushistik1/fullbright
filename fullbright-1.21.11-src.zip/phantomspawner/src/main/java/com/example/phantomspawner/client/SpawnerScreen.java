package com.example.phantomspawner.client;

import com.example.phantomspawner.SpawnerActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

/** Меню выбора координат и моба для фантомного спавнера. */
public class SpawnerScreen extends Screen {
    // Значения переживают закрытие меню в рамках сессии
    private static String lastX = "", lastY = "", lastZ = "", lastFilter = "";
    private static int lastIndex = 0;

    private TextFieldWidget xField, yField, zField, filterField;
    private final List<String> filtered = new ArrayList<>();
    private int index = lastIndex;
    private ButtonWidget mobButton;
    private Text status = Text.empty();

    public SpawnerScreen() {
        super(Text.literal("Фантомный спавнер"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2 - 80;

        // --- Координаты ---
        xField = field(cx - 100, y + 20, 60, "X", lastX);
        yField = field(cx - 30, y + 20, 60, "Y", lastY);
        zField = field(cx + 40, y + 20, 60, "Z", lastZ);

        addDrawableChild(ButtonWidget.builder(Text.literal("Моя позиция"), b -> fillMyPos())
                .dimensions(cx - 100, y + 46, 200, 20).build());

        // --- Выбор моба ---
        filterField = new TextFieldWidget(textRenderer, cx - 100, y + 92, 200, 20, Text.literal("Поиск"));
        filterField.setPlaceholder(Text.literal("Поиск моба (zombie, skeleton...)"));
        filterField.setText(lastFilter);
        filterField.setChangedListener(s -> { applyFilter(s); index = 0; updateMobButton(); });
        addDrawableChild(filterField);

        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> shift(-1))
                .dimensions(cx - 100, y + 118, 20, 20).build());
        mobButton = ButtonWidget.builder(Text.empty(), b -> shift(1))
                .dimensions(cx - 76, y + 118, 152, 20).build();
        addDrawableChild(mobButton);
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> shift(1))
                .dimensions(cx + 80, y + 118, 20, 20).build());

        // --- Действия ---
        addDrawableChild(ButtonWidget.builder(Text.literal("Создать"), b -> send(true))
                .dimensions(cx - 100, y + 150, 98, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Удалить"), b -> send(false))
                .dimensions(cx + 2, y + 150, 98, 20).build());

        applyFilter(lastFilter);
        updateMobButton();
    }

    private TextFieldWidget field(int x, int y, int w, String name, String value) {
        TextFieldWidget f = new TextFieldWidget(textRenderer, x, y, w, 20, Text.literal(name));
        f.setPlaceholder(Text.literal(name));
        f.setMaxLength(9);
        f.setText(value);
        addDrawableChild(f);
        return f;
    }

    private void fillMyPos() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        BlockPos p = mc.player.getBlockPos();
        xField.setText(String.valueOf(p.getX()));
        yField.setText(String.valueOf(p.getY()));
        zField.setText(String.valueOf(p.getZ()));
    }

    private void applyFilter(String text) {
        String q = text.trim().toLowerCase();
        filtered.clear();
        for (EntityType<?> t : Registries.ENTITY_TYPE) {
            if (t.getSpawnGroup() == SpawnGroup.MISC) continue;
            String id = Registries.ENTITY_TYPE.getId(t).toString();
            if (q.isEmpty() || id.contains(q)) filtered.add(id);
        }
        if (index >= filtered.size()) index = 0;
    }

    private void shift(int d) {
        if (filtered.isEmpty()) return;
        index = Math.floorMod(index + d, filtered.size());
        updateMobButton();
    }

    private void updateMobButton() {
        mobButton.setMessage(filtered.isEmpty()
                ? Text.literal("— ничего не найдено —")
                : Text.literal(filtered.get(index).replace("minecraft:", "")));
    }

    private void send(boolean add) {
        try {
            int x = Integer.parseInt(xField.getText().trim());
            int y = Integer.parseInt(yField.getText().trim());
            int z = Integer.parseInt(zField.getText().trim());
            String mob = filtered.isEmpty() ? "minecraft:zombie" : filtered.get(index);
            ClientPlayNetworking.send(new SpawnerActionPayload(add, new BlockPos(x, y, z), mob));
            status = Text.literal(add ? "Запрос на создание отправлен (ответ в чате)"
                                      : "Запрос на удаление отправлен (ответ в чате)");
        } catch (NumberFormatException e) {
            status = Text.literal("Введи целые числа в X, Y, Z");
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int cx = this.width / 2;
        int y = this.height / 2 - 80;
        context.drawCenteredTextWithShadow(textRenderer, this.title, cx, y - 12, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Координаты"), cx, y + 8, 0xFFAAAAAA);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Моб"), cx, y + 80, 0xFFAAAAAA);
        context.drawCenteredTextWithShadow(textRenderer, status, cx, y + 178, 0xFFFFFF55);
    }

    @Override
    public void removed() {
        lastX = xField.getText();
        lastY = yField.getText();
        lastZ = zField.getText();
        lastFilter = filterField.getText();
        lastIndex = index;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
