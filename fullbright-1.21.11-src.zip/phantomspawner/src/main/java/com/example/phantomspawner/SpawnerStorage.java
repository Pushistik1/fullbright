package com.example.phantomspawner;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Хранит спавнеры в config/phantomspawners.json. */
public class SpawnerStorage {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("phantomspawners.json");
    public static final List<SpawnerData> SPAWNERS = new ArrayList<>();

    public static void load() {
        SPAWNERS.clear();
        if (!Files.exists(FILE)) return;
        try (Reader r = Files.newBufferedReader(FILE)) {
            List<SpawnerData> list = GSON.fromJson(r, new TypeToken<List<SpawnerData>>() {}.getType());
            if (list != null) SPAWNERS.addAll(list);
        } catch (Exception e) {
            PhantomSpawnerMod.LOGGER.error("Не удалось загрузить спавнеры", e);
        }
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(FILE)) {
            GSON.toJson(SPAWNERS, w);
        } catch (Exception e) {
            PhantomSpawnerMod.LOGGER.error("Не удалось сохранить спавнеры", e);
        }
    }
}
