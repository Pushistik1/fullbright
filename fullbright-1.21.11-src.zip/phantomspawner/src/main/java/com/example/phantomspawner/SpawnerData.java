package com.example.phantomspawner;

import net.minecraft.util.math.BlockPos;

/** Один фантомный спавнер: измерение, координаты и id моба. */
public class SpawnerData {
    public String dimension;
    public int x, y, z;
    public String mob;

    public SpawnerData() {}

    public SpawnerData(String dimension, BlockPos pos, String mob) {
        this.dimension = dimension;
        this.x = pos.getX();
        this.y = pos.getY();
        this.z = pos.getZ();
        this.mob = mob;
    }

    public BlockPos pos() {
        return new BlockPos(x, y, z);
    }

    public boolean at(String dim, BlockPos p) {
        return dimension.equals(dim) && x == p.getX() && y == p.getY() && z == p.getZ();
    }
}
