package com.example.phantomspawner;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.text.Text;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class PhantomSpawnerMod implements ModInitializer {
    public static final String MOD_ID = "phantomspawner";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // ---- Настройки ----
    static final int SPAWN_INTERVAL = 100;      // тиков между попытками спавна (5 сек)
    static final int MAX_ALIVE = 4;             // макс. фантомных мобов у одного спавнера
    static final int ACTIVATION_RANGE = 24;     // игрок должен быть ближе (блоков)
    static final int SPAWN_RADIUS = 3;          // разброс спавна вокруг точки
    static final int LIFETIME_TICKS = 20 * 30;  // фантомы живут 30 секунд
    static final String TAG = "phantom_spawned";
    static final String TAG_UNTIL = "phantom_until_";

    @Override
    public void onInitialize() {
        SpawnerStorage.load();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) ->
                PhantomCommand.register(dispatcher));
        ServerTickEvents.END_WORLD_TICK.register(this::tickWorld);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> SpawnerStorage.save());
        PayloadTypeRegistry.playC2S().register(SpawnerActionPayload.ID, SpawnerActionPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(SpawnerActionPayload.ID, (payload, context) -> {
            var player = context.player();
            var server = context.server();
            if (!payload.mob().matches("[a-z0-9_.-]+:[a-z0-9_./-]+")) return;
            BlockPos p = payload.pos();
            String cmd = "phantomspawner " + (payload.add() ? "add " : "remove ")
                    + p.getX() + " " + p.getY() + " " + p.getZ()
                    + (payload.add() ? " " + payload.mob() : "");
            try {
                // Выполняем команду от имени игрока: права проверяются так же, как у /phantomspawner
                server.getCommandManager().getDispatcher().execute(cmd, player.getCommandSource());
            } catch (Exception e) {
                player.sendMessage(Text.literal("Нет прав (нужен оп) или ошибка команды."), false);
            }
        });
        LOGGER.info("Phantom Spawner загружен, спавнеров: {}", SpawnerStorage.SPAWNERS.size());
    }

    private void tickWorld(ServerWorld world) {
        long time = world.getTime();
        String dim = world.getRegistryKey().getValue().toString();

        for (SpawnerData sp : SpawnerStorage.SPAWNERS) {
            if (!sp.dimension.equals(dim)) continue;
            BlockPos pos = sp.pos();
            if (!world.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) continue;

            // 1) Исчезновение просроченных фантомов
            Box area = new Box(pos).expand(32);
            List<Entity> phantoms = world.getEntitiesByClass(Entity.class, area,
                    e -> e.getCommandTags().contains(TAG));
            for (Entity e : phantoms) {
                long until = untilOf(e);
                if (until > 0 && time >= until) {
                    world.spawnParticles(ParticleTypes.SOUL, e.getX(), e.getY() + 1, e.getZ(),
                            15, 0.3, 0.5, 0.3, 0.02);
                    e.discard();
                }
            }

            // 2) Видимые частицы самого спавнера
            if (time % 10 == 0) {
                world.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME,
                        pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 2, 0.2, 0.2, 0.2, 0.01);
            }

            // 3) Спавн новых
            if (time % SPAWN_INTERVAL != 0) continue;
            if (world.getClosestPlayer(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    ACTIVATION_RANGE, false) == null) continue;

            Identifier id = Identifier.tryParse(sp.mob);
            if (id == null || !Registries.ENTITY_TYPE.containsId(id)) continue;
            EntityType<?> type = Registries.ENTITY_TYPE.get(id);

            long alive = phantoms.stream().filter(e -> e.getType() == type && e.isAlive()).count();
            if (alive >= MAX_ALIVE) continue;

            spawnPhantom(world, type, pos, time);
        }
    }

    private void spawnPhantom(ServerWorld world, EntityType<?> type, BlockPos pos, long time) {
        Entity entity = type.create(world, SpawnReason.SPAWNER);
        if (entity == null) return;

        double x = pos.getX() + 0.5 + (world.random.nextDouble() * 2 - 1) * SPAWN_RADIUS;
        double z = pos.getZ() + 0.5 + (world.random.nextDouble() * 2 - 1) * SPAWN_RADIUS;
        entity.setPosition(x, pos.getY(), z);
        entity.setYaw(world.random.nextFloat() * 360f);
        if (!world.isSpaceEmpty(entity)) return; // не спавним внутри блоков

        // «Фантомность»: тег, время жизни, свечение
        entity.addCommandTag(TAG);
        entity.addCommandTag(TAG_UNTIL + (time + LIFETIME_TICKS));

        if (entity instanceof MobEntity mob) {
            mob.initialize(world, world.getLocalDifficulty(mob.getBlockPos()), SpawnReason.SPAWNER, null);
        }
        if (entity instanceof LivingEntity living) {
            living.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.GLOWING, LIFETIME_TICKS, 0, false, false));
        }

        world.spawnEntity(entity);
        world.spawnParticles(ParticleTypes.SOUL, x, pos.getY() + 1, z, 15, 0.3, 0.5, 0.3, 0.02);
    }

    private static long untilOf(Entity e) {
        for (String t : e.getCommandTags()) {
            if (t.startsWith(TAG_UNTIL)) {
                try { return Long.parseLong(t.substring(TAG_UNTIL.length())); }
                catch (NumberFormatException ignored) {}
            }
        }
        return -1;
    }
}
