package com.example.phantomspawner;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

/** Пакет клиент -> сервер: добавить (add=true) или удалить спавнер. */
public record SpawnerActionPayload(boolean add, BlockPos pos, String mob) implements CustomPayload {

    public static final CustomPayload.Id<SpawnerActionPayload> ID =
            new CustomPayload.Id<>(Identifier.of(PhantomSpawnerMod.MOD_ID, "spawner_action"));

    public static final PacketCodec<RegistryByteBuf, SpawnerActionPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.BOOLEAN, SpawnerActionPayload::add,
            BlockPos.PACKET_CODEC, SpawnerActionPayload::pos,
            PacketCodecs.STRING, SpawnerActionPayload::mob,
            SpawnerActionPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
